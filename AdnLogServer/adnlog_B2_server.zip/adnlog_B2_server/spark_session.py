from pyspark.sql import SparkSession
import logging
import os

def get_spark():
    """Tạo SparkSession với cấu hình tối ưu"""
    # Kiểm tra môi trường
    mode = os.environ.get('SPARK_MODE', 'remote')

    if mode == 'remote':
        # Cấu hình kết nối với Spark cluster qua Teleport
        spark = SparkSession.builder \
            .appName("AdnLogAPI-Remote") \
            .master("spark://adt-platform-dev-106-254:7077") \
            .config("spark.hadoop.fs.defaultFS", "hdfs://adt-platform-dev-106-254:8120") \
            .config("spark.sql.adaptive.enabled", "true") \
            .config("spark.sql.adaptive.coalescePartitions.enabled", "true") \
            .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
            .config("spark.sql.execution.arrow.pyspark.enabled", "true") \
            .config("spark.executor.memory", "2g") \
            .config("spark.executor.cores", "2") \
            .config("spark.executor.instances", "2") \
            .getOrCreate()
    elif mode == 'yarn':
        # Cấu hình production với YARN (khi chạy trên server)
        spark = SparkSession.builder \
            .appName("AdnLogAPI-YARN") \
            .master("yarn") \
            .config("spark.hadoop.fs.defaultFS", "hdfs://adt-platform-dev-106-254:8120") \
            .config("spark.sql.adaptive.enabled", "true") \
            .config("spark.sql.adaptive.coalescePartitions.enabled", "true") \
            .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
            .config("spark.sql.execution.arrow.pyspark.enabled", "true") \
            .getOrCreate()
    else:
        # Cấu hình local cho development
        spark = SparkSession.builder \
            .appName("AdnLogAPI-Local") \
            .master("local[*]") \
            .config("spark.sql.adaptive.enabled", "true") \
            .config("spark.sql.adaptive.coalescePartitions.enabled", "true") \
            .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer") \
            .getOrCreate()

    spark.sparkContext.setLogLevel("WARN")
    return spark