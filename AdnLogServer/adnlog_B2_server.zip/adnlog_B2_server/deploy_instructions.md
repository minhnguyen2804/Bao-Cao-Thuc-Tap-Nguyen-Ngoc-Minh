# 🚀 AdnLog API Server - Complete Deployment Guide

## 📋 Tổng quan
AdnLog API Server là một ứng dụng Flask + Spark để truy vấn dữ liệu log quảng cáo với hiệu suất cao.

## 📦 Package Contents

### Core Application Files:
- `app.py` - Main Flask application
- `spark_session.py` - Spark session configuration (đã sửa cho local mode)
- `data_processor.py` - Data processing logic
- `wsgi.py` - WSGI configuration for production

### Deployment Scripts:
- `start_server.sh` - Script khởi động server (production)
- `start_dev.sh` - Script khởi động development mode
- `test_api.sh` - Script test tất cả API endpoints
- `setup_environment.sh` - Script setup môi trường tự động

### Configuration:
- `requirements.txt` - Python dependencies (đã fix version tương thích)
- `deploy_instructions.md` - Hướng dẫn này

## � HƯỚNG DẪN DEPLOY NHANH (3 BƯỚC)

### Bước 1: Upload và Extract
```bash
# Upload file adnlog-api.zip lên server
# Extract
unzip adnlog-api.zip
cd adnlog-api
```

### Bước 2: Setup Environment (1 lệnh)
```bash
./setup_environment.sh
```

### Bước 3: Start Server (1 lệnh)
```bash
./start_server.sh
```

**🎯 Kết quả**: Server chạy tại `http://localhost:5000`

---

## 📋 HƯỚNG DẪN CHI TIẾT

### 🔧 Bước 1: Chuẩn bị Server

#### Yêu cầu hệ thống:
- **OS**: Linux (Ubuntu/CentOS)
- **Python**: 3.8+
- **Java**: 8+ (cho Spark)
- **Spark**: 3.4.3 (hoặc tương thích)

#### Kiểm tra môi trường:
```bash
python3 --version
java -version
```

### 🔧 Bước 2: Upload Code

#### Option A: Qua Web Interface
1. Upload file `adnlog-api.zip` qua Teleport/SSH client
2. Extract: `unzip adnlog-api.zip`

#### Option B: Qua Git (nếu có)
```bash
git clone <repository-url>
cd adnlog-api
```

### 🔧 Bước 3: Tự động Setup

```bash
# Cấp quyền và chạy setup
chmod +x setup_environment.sh
./setup_environment.sh
```

Script này sẽ:
- ✅ Tìm và cấu hình Spark
- ✅ Cài đặt Python dependencies
- ✅ Setup environment variables
- ✅ Test kết nối Spark

# Test kết nối
python test_connection.py
```

## 🔧 Bước 4: Chạy server

### Development mode:
```bash
python run_remote.py
```

### Production mode:
```bash
./start_server.sh
```

## 🔧 Bước 5: Test API

```bash
# Health check
curl "http://localhost:5000/health"

# Sample query
curl "http://localhost:5000/query?id_type=campaignId&id=123&mode=view&from=2024-07-01&to=2024-07-05"
```

## 🌐 Bước 6: Expose ra ngoài (nếu cần)

### Port forwarding qua Teleport:
```bash
# Forward port 5000 từ server ra local
ssh -L 5000:localhost:5000 username@server
```

### Nginx reverse proxy (trên server):
```nginx
server {
    listen 80;
    server_name your-domain.com;
    
    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## 🐛 Troubleshooting

### Lỗi kết nối Spark:
- Kiểm tra Spark cluster đang chạy: `jps | grep -i spark`
- Kiểm tra port: `netstat -tlnp | grep 7077`

### Lỗi HDFS:
- Kiểm tra HDFS: `hdfs dfsadmin -report`
- Test đọc file: `hdfs dfs -ls /data/Parquet/AdnLog/`

### Lỗi Python dependencies:
- Cài đặt lại: `pip install --upgrade flask pyspark`
- Kiểm tra Python version: `python --version` (cần >= 3.7)

## 📊 Monitoring

### Log files:
- Application logs: Check console output
- Spark logs: `/opt/spark/logs/`
- HDFS logs: `/opt/hadoop/logs/`

### Performance:
- Spark UI: `http://server:4040`
- HDFS UI: `http://server:9870`

## 🔒 Security Notes

- Server chỉ nên listen trên localhost (127.0.0.1)
- Sử dụng reverse proxy cho external access
- Implement authentication nếu cần
- Monitor resource usage (CPU, Memory)
